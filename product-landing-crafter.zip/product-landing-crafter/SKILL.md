---
name: product-landing-crafter
description: Build a focused product marketing landing page by grounding copy in product docs, designing on Ardot canvas, and exporting a standalone HTML file. Trigger when the user asks for a landing page, marketing site, promo page, or product showcase for an app/tool/product.
agent_created: true
---

# Product Landing Crafter

## Overview

This skill turns a product into a confident, single-scroll marketing landing page. It reads the product's real docs first, uses the product's own brand tokens when they exist, and delivers both an Ardot canvas design and a standalone deployable HTML file.

## When to Use

Use this skill for requests like:

- "帮我做一个 XX 的宣传站 / landing page / 官网"
- "给产品做一个营销页"
- "帮我设计一个应用推广页面"
- Any request that asks to promote an existing product/app/tool as a website.

## Workflow

### Step 1: Ground Copy in Product Docs

Before designing, read the product's core documents to avoid inventing features or misrepresenting the value proposition. Prefer reading these files in parallel:

1. `PRODUCT.md` — product positioning, first value, what it is / isn't, brand personality.
2. `PRD.md` — feature scope, target users, core principles, narrative priorities.
3. `README.md` — public pitch, quick start, comparison tables, key phrases.
4. `DESIGN.md` or `src/renderer/styles-foundation.css` — brand colors, typography, design authority.

Extract the concrete phrases the product already uses (e.g., "Agent 主路径，人终审") and reuse them. Do not invent a different positioning unless the user explicitly asks.

### Step 2: Choose Visual Direction

Respect the product's existing brand system when it exists:

- Look for a design authority file such as `styles-foundation.css`, `DESIGN.md`, `AGENTS.md`, or `CLAUDE.md`.
- Use the product's accent color (e.g., `#8b7cff` for WeMediaBuddy), not a generic or previously used palette from another project.
- Use the product's font family (e.g., Inter) and corner radius rules.
- If the product has no defined brand system, default to a clean dark theme with one accent and ask the user only if the choice is ambiguous.

### Step 3: Create Ardot Design File

Call `mcp__ardot__create_design` with a descriptive file name, then build the page at 1440px wide. Typical sections:

1. **Nav** — product wordmark + nav links + primary CTA.
2. **Hero** — kicker, bold headline, one-line value prop, two CTAs, product visual mockup.
3. **Problem / Hook** — the pain the product solves in product's own language.
4. **Core Loop / Features** — 4–6 cards describing the main workflow or capabilities.
5. **Crew / Roles / Differentiators** — what/who does the heavy lifting (optional).
6. **Comparison** — a clear "old way vs. this product" table.
7. **Download / CTA** — system requirements + main action.
8. **Footer** — brand tagline, links, copyright.

Use the brand tokens for fills, borders, typography, and buttons. Avoid shadows and gradients unless the brand system explicitly uses them. Verify sections with `mcp__ardot__capture_screenshot`.

### Step 4: Export Standalone HTML

Write a matching HTML file using the same content and visual tokens. Include:

- Google Fonts or system fallback for the chosen typeface.
- CSS variables matching the brand token values.
- Semantic HTML sections mirroring the Ardoc canvas structure.
- Responsive rules for tablet/mobile.
- Save to a sensible path such as `designs/<product>-landing.html`.

### Step 5: Present and Record

Use `present_files` to share both the canvas URL and the local HTML file. Append a brief note to the project's daily memory log describing the page structure, brand direction, and output files.

## Do's and Don'ts

- Do quote the product's own phrasing for key claims.
- Do use the product's real accent color; do not recycle a palette from a previous unrelated project.
- Do keep the page scannable: big headline, short paragraphs, 1–2 CTAs per section.
- Don't invent features or make promises not found in the docs.
- Don't describe internal engineering terms (MCP, IPC, CDP, revision, etc.) on a marketing page.
- Don't over-decorate; let one accent color do the work.
